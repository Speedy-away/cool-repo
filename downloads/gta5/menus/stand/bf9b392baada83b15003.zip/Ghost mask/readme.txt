Installation Path: mods/update/x64/dlcpacks/mpheist/dlc.rpf/x64/models/cdimages/mphesit_streamedpeds.rpf/mp_m_freemode_01_male_heist
then place the file in