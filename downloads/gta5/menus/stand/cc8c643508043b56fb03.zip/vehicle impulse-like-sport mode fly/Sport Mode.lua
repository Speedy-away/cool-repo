util.require_natives(1640181023)
local scaleform = require("ScaleformLib")
local sf = scaleform("instructional_buttons")
local is_vehicle_flying = false
local dont_stop = false
local no_collision = false
local stop_on_exit = true
local speed = 6
local vehflyt
vehflyt = menu.toggle(menu.my_root(), "Vehicle Fly", {"vehfly"}, "I recommend setting a hotkey to this option.", function(on_click)
    if on_click then
        local currentVehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
        if currentVehicle == 0 then
            util.toast("This function is only available when inside a vehicle. :/")
            menu.trigger_command(vehflyt, "off")
            return
        end
        local hasControl = NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(currentVehicle)
        local counter = 0
        if not hasControl then
            NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(currentVehicle)
            while not hasControl and counter < 100 do
                NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(currentVehicle)
                util.yield(5)
                hasControl = NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(currentVehicle)
                counter = counter + 1
            end
        end
        if not hasControl and counter >= 100 then
            util.toast("Failed to get control of vehicle. :/")
            menu.trigger_command(vehflyt, "off")
        else
            is_vehicle_flying = on_click
        end
    else
        is_vehicle_flying = false
    end
end)
menu.slider(menu.my_root(), "Speed", {"vflyspeed"}, "", 1, 100, 6, 1, function(on_change)
    speed = on_change
end)
menu.toggle(menu.my_root(), "Don't Stop After Input", {"vflynostop"}, "", function(on_click)
    dont_stop = on_click
end)
menu.toggle(menu.my_root(), "No Collision", {"vflynocollide"}, "", function(on_click)
    no_collision = on_click
end)
menu.toggle(menu.my_root(), "Stop on Exit", {"vflystopexit"}, "", function(on_click)
    stop_on_exit = on_click
end, true)
veh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
function do_vehicle_fly()
    veh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
    cam_pos = CAM.GET_GAMEPLAY_CAM_ROT(0)
    ENTITY.SET_ENTITY_COLLISION(veh, not no_collision, TRUE)
    ENTITY.SET_ENTITY_ROTATION(veh, cam_pos.x, cam_pos.y, cam_pos.z, 1, TRUE)
    -- aaron helped with this scaleform part :)
    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(6)
    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(7)
    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(8)
    HUD.HIDE_HUD_COMPONENT_THIS_FRAME(9)
    memory.write_int(memory.script_global(1645739+1121), 1)
    sf.CLEAR_ALL()
    sf.TOGGLE_MOUSE_BUTTONS(false)
    sf.SET_DATA_SLOT(2,PAD.GET_CONTROL_INSTRUCTIONAL_BUTTON(0, 21, true),"Up")
    sf.SET_DATA_SLOT(1,PAD.GET_CONTROL_INSTRUCTIONAL_BUTTON(0, 36, true),"Down")
    sf.SET_DATA_SLOT(0,PAD.GET_CONTROL_INSTRUCTIONAL_BUTTON(0, 55, true),"Sprint")
    sf.DRAW_INSTRUCTIONAL_BUTTONS()
    sf:draw_fullscreen()
    local locspeed = speed*10
    local locspeed2 = speed
    if PAD.IS_CONTROL_PRESSED(0, 76) then 
        locspeed = locspeed*2
        locspeed2 = locspeed2*2
    end
    if PAD.IS_CONTROL_PRESSED(2, 71) then
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0.0, speed, 0.0, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        else
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, locspeed)
        end
	end
    if PAD.IS_CONTROL_PRESSED(2, 72) then
		local lsp = speed
        if not PAD.IS_CONTROL_PRESSED(0, 61) then
            lsp = speed * 2
        end
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0.0, 0 - (lsp), 0.0, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        else
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, 0 - (locspeed))
        end
   end
    if PAD.IS_CONTROL_PRESSED(2, 63) then
        local lsp = (0 - speed)*2
        if not PAD.IS_CONTROL_PRESSED(0, 61) then
            lsp = 0 - speed
        end
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, (lsp), 0.0, 0.0, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0 - (locspeed), 0.0, 0.0, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        end
	end
    if PAD.IS_CONTROL_PRESSED(2, 64) then
        local lsp = speed
        if not PAD.IS_CONTROL_PRESSED(0, 61) then
            lsp = speed*2
        end
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, lsp, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, locspeed, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        end
    end
    if PAD.IS_CONTROL_PRESSED(2, 61) then
        local lsp = speed
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0.0, 0.0, lsp, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0.0, 0.0, locspeed, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        end
    end
    if PAD.IS_CONTROL_PRESSED(2, 62) then
        local lsp = speed
        if dont_stop then
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0.0, 0.0, 0 - (lsp), 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        else
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 1, 0.0, 0.0, 0 - (locspeed), 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
        end
    end
	if not dont_stop and not PAD.IS_CONTROL_PRESSED(2, 71) and not PAD.IS_CONTROL_PRESSED(2, 72) then
        VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, 0.0)
    end
    if TASK.GET_IS_TASK_ACTIVE(PLAYER.PLAYER_PED_ID(), 2) then
        menu.trigger_command(vehflyt, "off")
        if stop_on_exit then
            VEHICLE.SET_VEHICLE_FORWARD_SPEED(veh, 0.0)
        end
    end
    if not ENTITY.DOES_ENTITY_EXIST(veh) then
        menu.trigger_command(vehflyt, "off")
    end
end

util.create_tick_handler(function()
    VEHICLE.SET_VEHICLE_GRAVITY(veh, not is_vehicle_flying)
    if is_vehicle_flying then do_vehicle_fly() else ENTITY.SET_ENTITY_COLLISION(veh, true, TRUE) end
    return true
end)
util.on_stop(function()
    VEHICLE.SET_VEHICLE_GRAVITY(veh, true)
	ENTITY.SET_ENTITY_COLLISION(veh, true, true)
    sf:delete()
end)