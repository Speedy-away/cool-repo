--大部分源码来自Holys-Overlays.lua
util.require_natives("natives-1640181023")

util.keep_running()

function draw_string(s, x, y, scale, font)
	HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
	HUD.SET_TEXT_FONT(font or 0)
	HUD.SET_TEXT_SCALE(scale, scale)
	HUD.SET_TEXT_DROP_SHADOW()
	HUD.SET_TEXT_WRAP(0.0, 1.0)
	HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0)
	HUD.SET_TEXT_OUTLINE()
	HUD.SET_TEXT_EDGE(1, 0, 0, 0, 0)
	HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(s)
	HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y)
end

local fps = 0
util.create_thread(function()
    while true do
        fps = math.ceil(1/SYSTEM.TIMESTEP())
        util.yield(500)
    end
end)
local replayInterface = memory.read_long(memory.rip(memory.scan("48 8D 0D ? ? ? ? 48 8B D7 E8 ? ? ? ? 48 8D 0D ? ? ? ? 8A D8 E8 ? ? ? ? 84 DB 75 13 48 8D 0D") + 3))
local pedInterface = memory.read_long(replayInterface + 0x0018)
local vehInterface = memory.read_long(replayInterface + 0x0010)
local objectInterface = memory.read_long(replayInterface + 0x0028)
local pickupInterface = memory.read_long(replayInterface + 0x0020)
function zhujixvlie()
inviciamountint = 0
            for pid = 0, 31 do
                if players.exists(pid) and pid ~= players.user() then
                    local pped = players.user_ped(pid)
                    if pped ~= 0 then
                        if players.is_marked_as_modder(pid) then --is_marked_as_modder
                            inviciamountint = inviciamountint + 1
                        end
                    end
                end
local ente
                    local ent1e = players.user_ped()
                    local ent2e = PED.GET_VEHICLE_PED_IS_USING(players.user_ped())
                    if PED.IS_PED_IN_ANY_VEHICLE(ent1e,true) then
                        ente = ent2e
                    else
                        ente = ent1e
                    end
                    local speede = ENTITY.GET_ENTITY_SPEED(ente)
                    local speedcalce = speede * 3.6
                    myspeed1e = math.ceil(speedcalce)
            end
                inviciamountintt = inviciamountint
            draw_string(string.format("~italic~~p~"..myspeed1e.." ~w~KM/H"), 0.163,0.695, 0.4,1)
            draw_string(string.format("~italic~FPS: ~o~"..fps), 0.163,0.722, 0.4,1)
            draw_string(string.format("~italic~"..os.date("%X")), 0.163,0.749, 0.4,1)    
            draw_string(string.format("~italic~陪玩: ~g~"..#players.list()), 0.163,0.776, 0.4,1) 
            draw_string(string.format("~italic~坏孩子: ~r~"..inviciamountintt), 0.163,0.803, 0.4,1) 
            draw_string(string.format("~italic~主人: ~y~"..players.get_name(players.get_host())), 0.163,0.830, 0.4,1)
            draw_string(string.format("~italic~仆从: ~b~"..players.get_name(players.get_script_host())), 0.163,0.857, 0.4,1)
            draw_string(string.format("~italic~~bold~~c~Ped: ~s~"..memory.read_int(pedInterface + 0x0110).."/"..memory.read_int(pedInterface + 0x0108)), 0.163,0.884, 0.4,1)
            draw_string(string.format("~italic~~bold~~c~载具: ~s~"..memory.read_int(vehInterface + 0x0190).."/"..memory.read_int(vehInterface + 0x0188)), 0.163,0.911, 0.4,1)
            draw_string(string.format("~italic~~bold~~c~物体: ~s~"..memory.read_int(objectInterface + 0x0168).."/"..memory.read_int(objectInterface + 0x0160)), 0.163,0.938, 0.4,1)
            draw_string(string.format("~italic~~bold~~c~可拾取物: ~s~"..memory.read_int(pickupInterface + 0x0110).."/"..memory.read_int(pickupInterface + 0x0108)), 0.163,0.965, 0.4,1)
end

menu.toggle_loop(menu.my_root(), "主机序列", {"hostqu"}, "", function()
zhujixvlie()
end)