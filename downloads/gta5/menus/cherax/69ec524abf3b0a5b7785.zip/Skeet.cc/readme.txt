Use translation file for a better experience.

Replace the folder with your current one, or place the TranslationFile manually in documents/Cherax/Translations