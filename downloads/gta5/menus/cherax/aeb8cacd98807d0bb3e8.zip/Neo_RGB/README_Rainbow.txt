Neo_Rainbow_RGB

This variant uses a rainbow-gradient UI palette plus a smoothly hue-cycling toast_background.gif.
Note: the static header PNG assets can show a rainbow gradient, but only GIF-backed theme elements can animate smoothly.
