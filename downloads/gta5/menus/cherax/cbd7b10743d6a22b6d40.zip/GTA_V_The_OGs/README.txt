GTA V Green & Black Cherax Theme - v34
================================================

A Grand Theft Auto V-inspired ClickGUI theme for Cherax.

THEME
-----
- GTA V green + black visual style
- Custom GTA V character header artwork
- Custom GTA V toast artwork
- Green UI accents, panels, controls, and highlights
- Designed for Cherax ClickGUI

COMMUNITY
---------
Discord Server:
https://discord.gg/t9vF2vP8d

Discord:
animusx1337

GitHub:
https://github.com/xReVoLTiThemeDev/GTAV-Cherax

OTHER THEMES
------------
Neo theme collection:
- Neo Blue Original
- Neo Green
- Neo Orange
- Neo Purple
- Neo Red
- Neo RGB
- Neo / Dynamic RGB variants
- Cheems-NeoUI_Dynamic_RGB

CHERAX SCRIPTS & PROJECTS
-------------------------
Major projects:
- DriftGod
- Startup
- HustleMeter
- Flying Cars SA
- Track Generator
- Vehicle Paint Presets
- Velocity Vision Studio
- MiniGames
- WarGames
- BotBeGone
- Essentials
- PedWars
- LoudRadio
- Account Forensics
- Matchmaking Ladder Logger

Additional / experimental projects:
- NeoRGB Native Overlay
- Neo Dynamic RGB
- PTFX test / experimental scripts
- Vehicle conversion tools
- Vehicle Converter
- Utility scripts
- Cherax Lua experiments and development tools

NOTES
-----
DriftGod is the flagship drifting project.
Startup includes ClickGUI theme loading, scanning, and startup automation.
HustleMeter provides GTA Online money/session tracking and HUD tools.
Flying Cars SA recreates arcade-style flying-car gameplay.
MiniGames / WarGames provide custom GTA Online minigame experiences.

Thanks for using the theme and supporting the projects.