-- Russian startup pack for Cherax
-- Author: ilyavivitov

local settingsFile = ".json"
local translationFile = "Russian.json"
local translationListHash = 476570075
local translationLoadButtonHash = 1079343186
local targetTranslationName = "Russian"

local initTime = Time.GetEpocheMs()
local executionStep = 0
local transData = {}
local packTitle = "Russian Pack"
local authorTag = "ilyavivitov"

local function AddToast(title, text, duration, toastType)
    if GUI then
        pcall(function()
            GUI.AddToast(title, text, duration or 2000, toastType or 0)
        end)
    end
end

local function ReadTranslationData()
    local root = FileMgr.GetMenuRootPath() .. "\\Translations\\"
    local content = FileMgr.ReadFileContent(root .. translationFile)
    if not content or content == "" then
        return nil
    end

    local data = {}
    for key, value in content:gmatch('"(-?%d+)"%s*:%s*"(.-)"') do
        data[key] = value:gsub("\\n", "\n")
    end
    return data
end

local function TranslateListOptions()
    local data = ReadTranslationData()
    if not data then
        AddToast(packTitle, "Translation file not found: " .. translationFile, 3500, 1)
        return false
    end

    transData = data
    local features = FeatureMgr.GetAllFeatures()

    for _, feat in pairs(features) do
        pcall(function()
            local fType = feat:GetType()
            if fType >= 11 and fType <= 14 then
                local originalList = feat:GetList()
                if originalList then
                    local newList = {}
                    local changed = false

                    for _, optName in ipairs(originalList) do
                        local hash = Utils.Joaat(optName)
                        local hashStr = string.format("%.0f", hash)
                        if hash < 0 then
                            hashStr = string.format("%.0f", hash + 4294967296)
                        end

                        if transData[hashStr] then
                            table.insert(newList, transData[hashStr])
                            changed = true
                        else
                            table.insert(newList, optName)
                        end
                    end

                    if changed then
                        feat:SetList(newList)
                    end
                end
            end
        end)
    end

    return true
end

local function SelectTranslationInMenu()
    local listFeature = FeatureMgr.GetFeature(translationListHash)
    if not listFeature then
        return false
    end

    local success = false
    pcall(function()
        local files = listFeature:GetList()
        for i, fileName in ipairs(files) do
            if string.find(fileName, targetTranslationName) then
                listFeature:SetListIndex(i - 1)
                success = true
                break
            end
        end
    end)

    return success
end

local function ClickLoadTranslation()
    local loadButton = FeatureMgr.GetFeature(translationLoadButtonHash)
    if not loadButton then
        return false
    end

    local success = false
    pcall(function()
        loadButton:OnClick()
        success = true
    end)
    return success
end

local function ApplyTranslation()
    local listTranslated = TranslateListOptions()
    local selected = SelectTranslationInMenu()
    local loaded = ClickLoadTranslation()

    if not selected and not loaded and not listTranslated then
        AddToast(packTitle, "Failed to apply translation " .. authorTag, 3500, 1)
        return
    end

    if selected and loaded and listTranslated then
        AddToast(packTitle, "Russian translation applied. Lists and entries updated. Author: " .. authorTag, 2600, 0)
    elseif selected and loaded then
        AddToast(packTitle, "Russian translation applied. Author: " .. authorTag, 2400, 0)
    elseif selected then
        AddToast(packTitle, "Russian translation selected. Load it manually if needed. Author: " .. authorTag, 2800, 0)
    elseif listTranslated then
        AddToast(packTitle, "List translation applied. Author: " .. authorTag, 2400, 0)
    else
        AddToast(packTitle, "Translation processed partially. Author: " .. authorTag, 2600, 0)
    end
end

local function LoadSettings()
    local ok = false
    pcall(function()
        ok = FeatureMgr.LoadSettings(settingsFile)
    end)

    if ok then
        AddToast(packTitle, "Settings loaded: " .. settingsFile, 1200, 0)
    else
        AddToast(packTitle, "Settings file not found: " .. settingsFile, 3000, 1)
    end
end

local function OnPresentLoop()
    if executionStep == 2 then
        return
    end

    local elapsed = Time.GetEpocheMs() - initTime

    if executionStep == 0 and elapsed > 1000 then
        LoadSettings()
        executionStep = 1
    end

    if executionStep == 1 and elapsed > 4000 then
        ApplyTranslation()
        executionStep = 2
    end
end

EventMgr.RegisterHandler(eLuaEvent.ON_PRESENT, OnPresentLoop)
