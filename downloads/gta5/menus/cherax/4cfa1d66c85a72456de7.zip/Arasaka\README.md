# Installation

1. Copy the `Arasaka` folder to:
   `Documents\Cherax\Theme\ClickGUI`

2. Copy `REQUIRED_FONTS\Oxanium-SemiBold.ttf` to:
   `Documents\Cherax\Assets\Fonts`

3. Restart Cherax, select `Arasaka.json`, and click **Load Theme**.
