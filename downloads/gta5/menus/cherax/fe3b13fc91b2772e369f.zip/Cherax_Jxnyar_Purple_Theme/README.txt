Cherax Jxnyar Purple Theme

Files:
- theme.json: Cherax theme configuration based on Original.json, with a purple neon palette.
- background.jpg: the supplied Cherax/Jxnyar purple artwork.

Important compatibility note:
The provided Cherax JSON schema has no general menu-background image property. To avoid adding an unsupported JSON key that could break theme loading, the background is included separately. If your Cherax build supports a separate background-image selector, select background.jpg there. Otherwise the JSON alone cannot make the image appear behind the menu.

Install:
1. Back up your current theme JSON.
2. Import theme.json in Cherax's theme editor/import option.
3. Select background.jpg separately if your Cherax version provides a background-image setting.
