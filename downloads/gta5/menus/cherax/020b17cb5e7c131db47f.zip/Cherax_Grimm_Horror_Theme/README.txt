Cherax Grimm Horror Theme
========================

Dateien:
- theme.json: angepasstes Cherax-Theme mit Schwarz-/Grautönen und dunklen roten Akzenten.
- background.png: bereitgestelltes Hintergrundbild mit Cherax-Logo.

Wichtig:
Die gelieferte Original.json enthält keinen Schlüssel zur Einstellung eines allgemeinen Menü-Hintergrundbilds.
Daher wird background.png mitgeliefert, aber nicht durch theme.json automatisch aktiviert. Wenn deine Cherax-Version
eine separate Hintergrundbild-Option anbietet, wähle dort background.png aus.

Installation:
1. Sichere dein bisheriges Theme.
2. Importiere theme.json in Cherax.
3. Wähle background.png separat als Hintergrund, falls Cherax diese Funktion anbietet.
