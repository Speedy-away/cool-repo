CHERAX NEON PURPLE THEME
========================

Inhalt:
- Cherax_Neon_Purple_Theme.json : angepasste Cherax-Farbkonfiguration auf Neon-Violett
- background.jpg                : das erste Cherax-Bild als Hintergrund
- header_cherax_cutout.png      : ausgeschnittener Cherax-Logo-Header mit Transparenz
- toast_background.gif          : Toast-Hintergrund aus dem bereitgestellten Theme-Paket

Installation:
1. ZIP entpacken.
2. Die JSON-Datei in Cherax über die Theme-/Style-Importfunktion laden, sofern deine Version diese unterstützt.
3. Hintergrund und Header-Datei separat verwenden, falls deine Cherax-Version dafür eigene Bilddateien unterstützt.

Hinweis: Die JSON basiert auf deiner hochgeladenen GTA VI Theme-Datei; die Farben wurden auf Neon-Violett angepasst.
Die automatische Einbindung von Hintergrund/Header hängt von den unterstützten Funktionen deiner Cherax-Version ab.
